"""
Prime Vector LSM Portal – Configuration
Centralised settings for all environments.
Switch DATABASE_URI to MongoDB connection string when ready to upgrade.
"""

import os
from pathlib import Path

# Base project directory (two levels up from config/)
BASE_DIR = Path(__file__).resolve().parent.parent


class Config:
    # -------------------------------------------------------------------------
    # Core Flask Settings
    # -------------------------------------------------------------------------
    SECRET_KEY = os.environ.get("SECRET_KEY", "pv-lsm-super-secret-key-2024-change-in-prod")
    DEBUG = False
    TESTING = False

    # -------------------------------------------------------------------------
    # JSON Data Store (simulates a database for internship version)
    # Change DATA_DIR path or swap DataManager backend for MongoDB migration
    # -------------------------------------------------------------------------
    DATA_DIR = BASE_DIR / "data"

    # -------------------------------------------------------------------------
    # Email (credential delivery) — read from environment, never hardcode
    # real credentials here. If MAIL_USERNAME is unset, the mailer falls
    # back to a "print to console / show in dashboard" no-op mode so the
    # app still works fully in local/dev without SMTP configured.
    # -------------------------------------------------------------------------
    MAIL_SERVER = os.environ.get("MAIL_SERVER", "smtp.gmail.com")
    MAIL_PORT = int(os.environ.get("MAIL_PORT", 587))
    MAIL_USE_TLS = os.environ.get("MAIL_USE_TLS", "true").lower() == "true"
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME", "")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD", "")
    MAIL_DEFAULT_SENDER = os.environ.get("MAIL_DEFAULT_SENDER", "Prime Vector <no-reply@primevector.in>")

    # -------------------------------------------------------------------------
    # Uploads (assignment submissions)
    # -------------------------------------------------------------------------
    MAX_CONTENT_LENGTH = 25 * 1024 * 1024  # 25MB cap per request

    # -------------------------------------------------------------------------
    # Session
    # -------------------------------------------------------------------------
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    PERMANENT_SESSION_LIFETIME = 86400  # 24 hours in seconds

    # -------------------------------------------------------------------------
    # MongoDB (commented out – uncomment when migrating)
    # -------------------------------------------------------------------------
    # MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/prime_vector_lsm")


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False


# Active configuration
config = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig,
}
