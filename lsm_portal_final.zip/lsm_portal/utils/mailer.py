"""
Prime Vector LSM Portal – Mailer
Sends credential / notification emails via SMTP (smtplib, stdlib only —
no extra dependency needed). Falls back to a safe no-op ("not configured")
mode when MAIL_USERNAME/MAIL_PASSWORD aren't set, so local development and
demos never break just because SMTP isn't wired up yet.
"""

import smtplib
import ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from flask import current_app


BRAND_COLOR = "#0ea5e9"   # matches --brand-primary-ish tone used across the portal
BRAND_NAME = "Prime Vector"


def _is_configured():
    return bool(
        current_app.config.get("MAIL_USERNAME") and current_app.config.get("MAIL_PASSWORD")
    )


def _send_raw(to_email: str, subject: str, html_body: str, text_body: str) -> tuple[bool, str]:
    """
    Low-level send. Returns (success, message).
    If SMTP isn't configured, returns (False, "not_configured") without
    raising — callers should treat that as "show credentials on-screen
    instead" rather than a hard error.
    """
    if not _is_configured():
        return False, "not_configured"

    cfg = current_app.config
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = cfg.get("MAIL_DEFAULT_SENDER", cfg["MAIL_USERNAME"])
    msg["To"] = to_email
    msg.attach(MIMEText(text_body, "plain"))
    msg.attach(MIMEText(html_body, "html"))

    try:
        context = ssl.create_default_context()
        with smtplib.SMTP(cfg["MAIL_SERVER"], cfg["MAIL_PORT"]) as server:
            if cfg.get("MAIL_USE_TLS", True):
                server.starttls(context=context)
            server.login(cfg["MAIL_USERNAME"], cfg["MAIL_PASSWORD"])
            server.sendmail(cfg["MAIL_USERNAME"], [to_email], msg.as_string())
        return True, "sent"
    except Exception as exc:  # noqa: BLE001 — surface any SMTP failure to the caller
        return False, str(exc)


def _credentials_html(name: str, role: str, login_url: str, email: str, password: str) -> str:
    role_label = role.capitalize()
    return f"""
    <div style="font-family: Inter, Arial, sans-serif; max-width: 480px; margin: 0 auto; padding: 32px 24px; background:#0f172a; color:#e2e8f0; border-radius: 12px;">
      <h2 style="color:{BRAND_COLOR}; margin-top:0;">Welcome to {BRAND_NAME}, {name}! 🚀</h2>
      <p>Your <strong>{role_label}</strong> account has been created. Here are your login details:</p>
      <table style="width:100%; margin: 20px 0; border-collapse: collapse;">
        <tr>
          <td style="padding:8px 0; color:#94a3b8;">Login URL</td>
          <td style="padding:8px 0;"><a href="{login_url}" style="color:{BRAND_COLOR};">{login_url}</a></td>
        </tr>
        <tr>
          <td style="padding:8px 0; color:#94a3b8;">Email</td>
          <td style="padding:8px 0;">{email}</td>
        </tr>
        <tr>
          <td style="padding:8px 0; color:#94a3b8;">Temporary Password</td>
          <td style="padding:8px 0; font-weight:700;">{password}</td>
        </tr>
      </table>
      <p style="font-size:13px; color:#94a3b8;">
        For your security, please log in and change this password as soon as possible.
      </p>
      <p style="font-size:13px; color:#94a3b8; margin-top:24px;">
        — The {BRAND_NAME} Team
      </p>
    </div>
    """


def _credentials_text(name: str, role: str, login_url: str, email: str, password: str) -> str:
    return (
        f"Welcome to {BRAND_NAME}, {name}!\n\n"
        f"Your {role.capitalize()} account has been created.\n\n"
        f"Login URL: {login_url}\n"
        f"Email: {email}\n"
        f"Temporary Password: {password}\n\n"
        f"Please log in and change this password as soon as possible.\n\n"
        f"— The {BRAND_NAME} Team"
    )


def send_credentials_email(to_email: str, name: str, role: str, login_url: str, password: str) -> tuple[bool, str]:
    """
    Send a welcome email with login credentials.
    role: "student" | "mentor" | "admin"
    Returns (success, status) where status is "sent", "not_configured", or an error string.
    """
    subject = f"Your {BRAND_NAME} {role.capitalize()} Account is Ready"
    html_body = _credentials_html(name, role, login_url, to_email, password)
    text_body = _credentials_text(name, role, login_url, to_email, password)
    return _send_raw(to_email, subject, html_body, text_body)
