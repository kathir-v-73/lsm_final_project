"""
Prime Vector LSM Portal – Main Application
==========================================
Flask application factory. Registers all blueprints.
Run with: python app.py
"""

from flask import Flask, render_template, redirect, url_for, session
from config.config import config
from datetime import datetime
import os

# ------------------------------------------------------------------
# Blueprint Imports
# ------------------------------------------------------------------
from routes.auth import auth_bp
from routes.student import student_bp
from routes.mentor import mentor_bp
from routes.admin import admin_bp


def create_app(env: str = "development") -> Flask:
    """
    Application factory.
    Creates and configures the Flask application.

    Args:
        env: Environment name ('development' | 'production')

    Returns:
        Configured Flask application instance.
    """
    app = Flask(__name__)

    # ----------------------------------------------------------------
    # Load Configuration
    # ----------------------------------------------------------------
    app.config.from_object(config.get(env, config["default"]))

    # ----------------------------------------------------------------
    # Register Blueprints
    # ----------------------------------------------------------------
    app.register_blueprint(auth_bp)           # /login/student, /login/mentor, /login/admin, /logout
    app.register_blueprint(student_bp)        # /student/dashboard
    app.register_blueprint(mentor_bp)         # /mentor/dashboard
    app.register_blueprint(admin_bp)          # /admin/dashboard

    # ----------------------------------------------------------------
    # Landing / Root Routes
    # ----------------------------------------------------------------
    from flask import Blueprint
    from pathlib import Path
    from utils.data_manager import DataManager

    main_bp = Blueprint("main", __name__)
    _dm = DataManager(Path(__file__).resolve().parent / "data")

    @main_bp.route("/")
    def landing():
        """Public landing page — content + course catalogue only (no login here)."""
        courses = _dm.get_all("courses")
        dashboard_data = _dm.find_one("dashboard", {}) or {}
        stats = dashboard_data.get("platform_stats", {})
        return render_template("landing.html", courses=courses, stats=stats)

    @main_bp.route("/dashboard")
    def dashboard_redirect():
        """Smart redirect based on session role."""
        role = session.get("role")
        if role == "student":
            return redirect(url_for("student.dashboard"))
        elif role == "mentor":
            return redirect(url_for("mentor.dashboard"))
        elif role == "admin":
            return redirect(url_for("admin.dashboard"))
        return redirect(url_for("main.landing"))

    from flask import request, jsonify

    @main_bp.route("/enroll", methods=["POST"])
    def enroll_interest():
        """
        Public 'Enroll Now' handler.
        A visitor picks a course on the landing page -> this creates a pending
        request that only the admin can see/approve. No account or login is
        created here; the student portal is intentionally not reachable from
        this page (see routes/auth.py + /portal-access).
        """
        data = request.get_json(force=True, silent=True) or {}
        name = (data.get("name") or "").strip()
        email = (data.get("email") or "").strip().lower()
        phone = (data.get("phone") or "").strip()
        course_id = data.get("course_id")

        if not name or not email or not course_id:
            return jsonify({"success": False, "message": "Name, email and course are required."}), 400

        course = _dm.get_by_id("courses", course_id)
        request_record = {
            "name": name,
            "email": email,
            "phone": phone,
            "course_id": course_id,
            "course_title": course.get("title") if course else "Unknown Course",
            "status": "pending",              # pending | approved | rejected
            "created_at": datetime.now().isoformat(),
        }
        result = _dm.create("enrollment_requests", request_record)

        # Notify every admin so it shows up in their notification bell
        for admin in _dm.get_all("admins"):
            _dm.create("notifications", {
                "user_id": admin["id"],
                "user_role": "admin",
                "title": "New Enrollment Request",
                "message": f"{name} wants to enroll in {request_record['course_title']}.",
                "type": "enrollment",
                "read": False,
                "timestamp": datetime.now().isoformat(),
                "icon": "📝",
            })

        return jsonify({"success": True, "message": "Thanks! Our admin team will reach out shortly.", "request": result})

    app.register_blueprint(main_bp)

    # ----------------------------------------------------------------
    # Error Handlers
    # ----------------------------------------------------------------
    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/403.html"), 403

    @app.errorhandler(500)
    def server_error(e):
        return render_template("errors/500.html"), 500

    return app


# ------------------------------------------------------------------
# Entry Point
# ------------------------------------------------------------------
if __name__ == "__main__":
    env = os.environ.get("FLASK_ENV", "development")
    app = create_app(env)
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=(env == "development")
    )
