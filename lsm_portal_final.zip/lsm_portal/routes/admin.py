"""
Prime Vector LSM Portal – Admin Routes
All protected routes for the admin dashboard.
"""

from flask import Blueprint, render_template, session, jsonify, request, url_for
from pathlib import Path
from datetime import datetime
from utils.data_manager import DataManager
from utils.mailer import send_credentials_email
from routes.auth import admin_required, main_admin_required

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")

_BASE = Path(__file__).resolve().parent.parent
dm = DataManager(_BASE / "data")


@admin_bp.route("/dashboard")
@admin_required
def dashboard():
    """Main admin dashboard – system-wide statistics and management."""
    # Load all collections
    students = dm.get_all("students")
    mentors = dm.get_all("mentors")
    courses = dm.get_all("courses")
    assignments = dm.get_all("assignments")
    announcements = dm.get_all("announcements")
    admins = dm.get_all("admins")
    dashboard_data = dm.find_one("dashboard", {}) or {}
    enrollment_requests = dm.get_all("enrollment_requests")
    pending_enrollment_count = sum(1 for r in enrollment_requests if r.get("status") == "pending")

    # Admin profile
    user_id = session.get("user_id")
    admin = dm.get_by_id("admins", user_id)
    is_main_admin = bool(admin and admin.get("admin_level") == "main")

    # Notifications for admin
    all_notifications = dm.get_all("notifications")
    my_notifications = [n for n in all_notifications if n.get("user_id") == user_id]
    unread_count = sum(1 for n in my_notifications if not n.get("read", True))

    # Platform statistics
    stats = {
        "total_students": len(students),
        "total_mentors": len(mentors),
        "total_courses": len(courses),
        "total_assignments": len(assignments),
        "certificates_issued": dashboard_data.get("platform_stats", {}).get("certificates_issued", 0),
        "active_sessions": dashboard_data.get("platform_stats", {}).get("active_sessions", 0),
        "success_rate": dashboard_data.get("platform_stats", {}).get("success_rate", 0),
        "avg_rating": dashboard_data.get("platform_stats", {}).get("avg_course_rating", 0),
    }

    # Recent logins from dashboard.json
    recent_logins = dashboard_data.get("recent_logins", [])

    # Dynamic course popularity chart data based on enrolled count
    course_popularity = {
        "labels": [c["title"] for c in courses],
        "data": [c.get("enrolled_count", 0) for c in courses]
    }
    dashboard_data["course_popularity"] = course_popularity

    # Load system configuration settings
    settings = dm.get_dict("settings")
    if not settings:
        settings = {
            "app_name": "Prime Vector",
            "tagline": "Your vector towards success",
            "email": "primevectorprivatelimited@gmail.com",
            "phone": "+91 8220082896",
            "address": "No.74/22f11, 3rd Floor, HV Arcade, Bagalur Road, Hosur, Krishnagiri, Tamil Nadu - 635109",
            "maintenance_mode": "no",
            "allow_registrations": "yes",
            "logo_url": "/static/images/primevector_logo.png"
        }

    return render_template(
        "admin/dashboard.html",
        admin=admin,
        admins=admins,
        students=students,
        mentors=mentors,
        courses=courses,
        stats=stats,
        announcements=announcements,
        recent_logins=recent_logins,
        dashboard_data=dashboard_data,
        notifications=my_notifications,
        unread_count=unread_count,
        settings=settings,
        enrollment_requests=enrollment_requests,
        pending_enrollment_count=pending_enrollment_count,
        is_main_admin=is_main_admin,
    )


@admin_bp.route("/enrollment-requests", methods=["GET"])
@admin_required
def get_enrollment_requests():
    """Return all enrollment requests as JSON (AJAX)."""
    return jsonify(dm.get_all("enrollment_requests"))


@admin_bp.route("/enrollment-requests/<request_id>/approve", methods=["POST"])
@admin_required
def approve_enrollment(request_id):
    """
    Approve a pending enrollment: creates the student account (if new),
    enrolls them in the requested course, and emails the credentials to
    the student. If SMTP isn't configured (or sending fails), the
    generated password is returned in the response instead, so the admin
    can share it manually.
    """
    req = dm.get_by_id("enrollment_requests", request_id)
    if not req:
        return jsonify({"success": False, "message": "Request not found."})

    existing = dm.find_one("students", {"email": req["email"]})
    if existing:
        enrolled = existing.get("courses_enrolled", [])
        if req["course_id"] not in enrolled:
            enrolled.append(req["course_id"])
            dm.update("students", existing["id"], {"courses_enrolled": enrolled})
        student = existing
        generated_password = None
    else:
        import secrets
        generated_password = secrets.token_urlsafe(6)
        student = dm.create("students", {
            "name": req["name"],
            "email": req["email"],
            "password": generated_password,
            "must_change_password": True,
            "avatar": "".join([p[0].upper() for p in req["name"].split() if p][:2]),
            "phone": req.get("phone", ""),
            "batch": datetime.now().strftime("%Y-%b"),
            "enrolled_date": datetime.now().strftime("%Y-%m-%d"),
            "courses_enrolled": [req["course_id"]],
            "overall_progress": 0,
            "grade": "-",
            "assignments_submitted": 0,
            "assignments_total": 0,
            "certificates_earned": 0,
            "streak_days": 0,
            "last_active": datetime.now().strftime("%Y-%m-%d"),
            "bio": "", "skills": [], "linkedin": "", "location": "",
        })

    dm.update("enrollment_requests", request_id, {"status": "approved"})

    email_sent = False
    email_status = "not_sent"
    if generated_password:
        login_url = url_for("auth.login_student", _external=True)
        email_sent, email_status = send_credentials_email(
            to_email=student["email"], name=student["name"], role="student",
            login_url=login_url, password=generated_password,
        )

    return jsonify({
        "success": True,
        "student": {k: v for k, v in student.items() if k != "password"},
        "generated_password": generated_password,   # None if account already existed
        "email_sent": email_sent,
        "email_status": email_status,                # "sent" | "not_configured" | error string
    })


@admin_bp.route("/enrollment-requests/<request_id>/reject", methods=["POST"])
@admin_required
def reject_enrollment(request_id):
    """Reject a pending enrollment request (AJAX)."""
    result = dm.update("enrollment_requests", request_id, {"status": "rejected"})
    return jsonify({"success": bool(result)})


@admin_bp.route("/meeting/create", methods=["POST"])
@admin_required
def create_mentor_meeting():
    """
    Schedule a Zoom meeting for mentors (e.g. all-mentor sync, training).
    Reuses the same sessions.json store as mentor Q&A sessions, just
    scoped with type='mentor_meeting' and target_mentors instead of
    target_students.
    """
    data = request.get_json(silent=True) or {}
    title = (data.get("title") or "").strip()
    zoom_join_url = (data.get("zoom_join_url") or "").strip()
    scheduled_at = data.get("scheduled_at")
    if not title or not zoom_join_url or not scheduled_at:
        return jsonify({"success": False, "message": "Title, Zoom link and scheduled time are required."})

    target_mentors = data.get("target_mentors") or [m["id"] for m in dm.get_all("mentors")]

    new_session = {
        "type": "mentor_meeting",
        "created_by_admin_id": session.get("user_id"),
        "title": title,
        "zoom_join_url": zoom_join_url,
        "scheduled_at": scheduled_at,
        "duration_minutes": int(data.get("duration_minutes", 30)),
        "target_mentors": target_mentors,
        "attendance": [],
    }
    result = dm.create("sessions", new_session)

    for mid in target_mentors:
        dm.create("notifications", {
            "user_id": mid,
            "user_role": "mentor",
            "title": "Mentor Meeting Scheduled",
            "message": f"Admin scheduled \"{title}\" — check your notifications to join.",
            "type": "session",
            "read": False,
            "timestamp": datetime.now().isoformat(),
            "icon": "🎥",
        })

    return jsonify({"success": True, "session": result})


@admin_bp.route("/announcement/create", methods=["POST"])
@admin_required
def create_announcement():
    """Create a new announcement (AJAX)."""
    data = request.get_json()
    announcement = {
        "title": data.get("title"),
        "content": data.get("content"),
        "author": session.get("user_name"),
        "author_role": "admin",
        "target_roles": data.get("target_roles", ["student", "mentor"]),
        "priority": data.get("priority", "medium"),
        "pinned": data.get("pinned", False),
        "icon": data.get("icon", "📢"),
        "date": datetime.now().strftime("%Y-%m-%d")
    }
    result = dm.create("announcements", announcement)
    return jsonify({"success": True, "announcement": result})


@admin_bp.route("/students", methods=["GET"])
@admin_required
def get_students():
    """Return all students as JSON (AJAX)."""
    students = dm.get_all("students")
    safe = [{k: v for k, v in s.items() if k != "password"} for s in students]
    return jsonify(safe)


@admin_bp.route("/mentors", methods=["GET"])
@admin_required
def get_mentors():
    """Return all mentors as JSON (AJAX)."""
    mentors = dm.get_all("mentors")
    safe = [{k: v for k, v in m.items() if k != "password"} for m in mentors]
    return jsonify(safe)


# ------------------------------------------------------------------
# Admin CRUD operations
# ------------------------------------------------------------------

@admin_bp.route("/create", methods=["POST"])
@admin_required
def create_admin():
    """Create a new admin (AJAX). Capped at 5 total: 1 Main Admin + 4 standard."""
    data = request.get_json()
    email = data.get("email", "").strip().lower()

    if dm.email_exists("admins", email) or dm.email_exists("students", email) or dm.email_exists("mentors", email):
        return jsonify({"success": False, "message": "Email already exists in system."})

    existing_admins = dm.get_all("admins")
    if len(existing_admins) >= 5:
        return jsonify({
            "success": False,
            "message": "Admin limit reached: the portal allows a maximum of 5 admins (1 Main Admin + 4 standard admins)."
        })

    name = data.get("name", "").strip()
    new_admin = {
        "name": name,
        "email": email,
        "password": data.get("password", "admin123"),
        "avatar": "".join([part[0].upper() for part in name.split() if part][:2]),
        "role": data.get("role", "admin"),
        "admin_level": "standard",  # new admins are always standard; only the seeded a001 is "main"
        "phone": data.get("phone", ""),
        "joined_date": datetime.now().strftime("%Y-%m-%d"),
        "location": data.get("location", "")
    }
    result = dm.create("admins", new_admin)
    return jsonify({"success": True, "admin": result})


@admin_bp.route("/edit/<admin_id>", methods=["POST"])
@admin_required
def edit_admin(admin_id):
    """
    Edit an existing admin (AJAX).
    Standard admins may only edit their own profile. Only the Main Admin
    may edit other admins' records. admin_level is never changed here —
    see /admin/transfer-main-admin for ownership transfer.
    """
    acting_admin = dm.get_by_id("admins", session.get("user_id"))
    is_main = acting_admin and acting_admin.get("admin_level") == "main"

    if not is_main and str(admin_id) != str(session.get("user_id")):
        return jsonify({"success": False, "message": "Only the Main Admin can edit other admins."}), 403

    data = request.get_json()
    email = data.get("email", "").strip().lower()

    if dm.email_exists("admins", email, exclude_id=admin_id):
        return jsonify({"success": False, "message": "Email already exists."})

    name = data.get("name", "").strip()
    updates = {
        "name": name,
        "email": email,
        "avatar": "".join([part[0].upper() for part in name.split() if part][:2]),
        "phone": data.get("phone", ""),
        "location": data.get("location", "")
    }
    # Only the Main Admin may change another admin's role label; a standard
    # admin editing themselves cannot self-promote.
    if is_main:
        updates["role"] = data.get("role", "admin")

    if data.get("password"):
        updates["password"] = data.get("password")

    result = dm.update("admins", admin_id, updates)
    return jsonify({"success": True, "admin": result})


@admin_bp.route("/delete/<admin_id>", methods=["POST"])
@main_admin_required
def delete_admin(admin_id):
    """Delete an admin (AJAX). Main-Admin-only. The Main Admin can never be deleted."""
    target = dm.get_by_id("admins", admin_id)
    if not target:
        return jsonify({"success": False, "message": "Admin not found."})

    if target.get("admin_level") == "main":
        return jsonify({"success": False, "message": "The Main Admin account cannot be deleted."})

    if str(admin_id) == str(session.get("user_id")):
        return jsonify({"success": False, "message": "You cannot delete your own account."})

    result = dm.delete("admins", admin_id)
    return jsonify({"success": result})


@admin_bp.route("/transfer-main-admin/<admin_id>", methods=["POST"])
@main_admin_required
def transfer_main_admin(admin_id):
    """
    Transfer Main Admin ownership to another existing standard admin.
    Main-Admin-only. The current Main Admin becomes a standard admin;
    the target becomes the new Main Admin. Requires the CURRENT main
    admin's session to call this (enforced by @main_admin_required),
    which acts as the confirmation step.
    """
    current_main = dm.get_by_id("admins", session.get("user_id"))
    target = dm.get_by_id("admins", admin_id)

    if not target:
        return jsonify({"success": False, "message": "Target admin not found."})
    if target.get("admin_level") == "main":
        return jsonify({"success": False, "message": "That admin is already the Main Admin."})

    dm.update("admins", current_main["id"], {"admin_level": "standard"})
    dm.update("admins", target["id"], {"admin_level": "main"})

    return jsonify({"success": True, "message": f"Main Admin ownership transferred to {target['name']}."})


# ------------------------------------------------------------------
# Student CRUD operations
# ------------------------------------------------------------------

@admin_bp.route("/student/create", methods=["POST"])
@admin_required
def create_student():
    """Create a new student (AJAX). Emails login credentials if a password wasn't supplied."""
    data = request.get_json()
    email = data.get("email", "").strip().lower()
    
    if dm.email_exists("students", email) or dm.email_exists("admins", email) or dm.email_exists("mentors", email):
        return jsonify({"success": False, "message": "Email already exists in system."})

    name = data.get("name", "").strip()
    provided_password = data.get("password", "").strip()
    generated_password = None
    if not provided_password:
        import secrets
        generated_password = secrets.token_urlsafe(6)
    password = provided_password or generated_password

    student = {
        "name": name,
        "email": email,
        "password": password,
        "must_change_password": bool(generated_password),
        "avatar": "".join([part[0].upper() for part in name.split() if part][:2]),
        "phone": data.get("phone", ""),
        "batch": data.get("batch", "Batch-2024-C"),
        "enrolled_date": datetime.now().strftime("%Y-%m-%d"),
        "courses_enrolled": data.get("courses_enrolled", []),
        "overall_progress": int(data.get("overall_progress", 0)),
        "grade": data.get("grade", "B"),
        "assignments_submitted": 0,
        "assignments_total": 0,
        "certificates_earned": 0,
        "streak_days": 0,
        "last_active": datetime.now().strftime("%Y-%m-%d"),
        "bio": data.get("bio", ""),
        "skills": [s.strip() for s in data.get("skills", "").split(",") if s.strip()],
        "linkedin": data.get("linkedin", ""),
        "location": data.get("location", "")
    }
    
    result = dm.create("students", student)

    email_sent, email_status = False, "not_sent"
    if generated_password:
        email_sent, email_status = send_credentials_email(
            to_email=email, name=name, role="student",
            login_url=url_for("auth.login_student", _external=True),
            password=generated_password,
        )

    return jsonify({
        "success": True,
        "student": {k: v for k, v in result.items() if k != "password"},
        "generated_password": generated_password,
        "email_sent": email_sent,
        "email_status": email_status,
    })


@admin_bp.route("/student/edit/<student_id>", methods=["POST"])
@admin_required
def edit_student(student_id):
    """Edit an existing student (AJAX)."""
    data = request.get_json()
    email = data.get("email", "").strip().lower()
    
    if dm.email_exists("students", email, exclude_id=student_id):
        return jsonify({"success": False, "message": "Email already exists."})
        
    name = data.get("name", "").strip()
    updates = {
        "name": name,
        "email": email,
        "avatar": "".join([part[0].upper() for part in name.split() if part][:2]),
        "phone": data.get("phone", ""),
        "batch": data.get("batch", "Batch-2024-C"),
        "courses_enrolled": data.get("courses_enrolled", []),
        "overall_progress": int(data.get("overall_progress", 0)),
        "grade": data.get("grade", "B"),
        "bio": data.get("bio", ""),
        "skills": [s.strip() for s in data.get("skills", "").split(",") if s.strip()],
        "linkedin": data.get("linkedin", ""),
        "location": data.get("location", "")
    }
    if data.get("password"):
        updates["password"] = data.get("password")
        
    result = dm.update("students", student_id, updates)
    return jsonify({"success": True, "student": result})


@admin_bp.route("/student/delete/<student_id>", methods=["POST"])
@admin_required
def delete_student(student_id):
    """Delete a student (AJAX)."""
    result = dm.delete("students", student_id)
    return jsonify({"success": result})


@admin_bp.route("/student/<student_id>/resend-credentials", methods=["POST"])
@admin_required
def resend_student_credentials(student_id):
    """Generate a fresh password for a student and email it to them."""
    student = dm.get_by_id("students", student_id)
    if not student:
        return jsonify({"success": False, "message": "Student not found."})

    import secrets
    new_password = secrets.token_urlsafe(6)
    dm.update("students", student_id, {"password": new_password, "must_change_password": True})

    email_sent, email_status = send_credentials_email(
        to_email=student["email"], name=student["name"], role="student",
        login_url=url_for("auth.login_student", _external=True),
        password=new_password,
    )
    return jsonify({
        "success": True,
        "generated_password": new_password,
        "email_sent": email_sent,
        "email_status": email_status,
    })


# ------------------------------------------------------------------
# Mentor CRUD operations
# ------------------------------------------------------------------

@admin_bp.route("/mentor/create", methods=["POST"])
@admin_required
def create_mentor():
    """Create a new mentor (AJAX). Emails login credentials if a password wasn't supplied."""
    data = request.get_json()
    email = data.get("email", "").strip().lower()
    
    if dm.email_exists("mentors", email) or dm.email_exists("admins", email) or dm.email_exists("students", email):
        return jsonify({"success": False, "message": "Email already exists in system."})

    name = data.get("name", "").strip()
    provided_password = data.get("password", "").strip()
    generated_password = None
    if not provided_password:
        import secrets
        generated_password = secrets.token_urlsafe(6)
    password = provided_password or generated_password

    mentor = {
        "name": name,
        "email": email,
        "password": password,
        "must_change_password": bool(generated_password),
        "avatar": "".join([part[0].upper() for part in name.split() if part][:2]),
        "phone": data.get("phone", ""),
        "specialty": data.get("specialty", ""),
        "experience_years": int(data.get("experience_years", 5)),
        "rating": 4.5,
        "bio": data.get("bio", ""),
        "courses_assigned": data.get("courses_assigned", []),
        "students_assigned": [],
        "total_students_mentored": 0,
        "certificates_issued": 0,
        "joined_date": datetime.now().strftime("%Y-%m-%d"),
        "qualification": data.get("qualification", ""),
        "linkedin": data.get("linkedin", ""),
        "location": data.get("location", ""),
        "skills": [s.strip() for s in data.get("skills", "").split(",") if s.strip()]
    }
    
    result = dm.create("mentors", mentor)
    
    # Sync with courses assigned
    for cid in mentor["courses_assigned"]:
        dm.update("courses", cid, {"mentor_id": result["id"], "mentor_name": name})

    email_sent, email_status = False, "not_sent"
    if generated_password:
        email_sent, email_status = send_credentials_email(
            to_email=email, name=name, role="mentor",
            login_url=url_for("auth.login_mentor", _external=True),
            password=generated_password,
        )

    return jsonify({
        "success": True,
        "mentor": {k: v for k, v in result.items() if k != "password"},
        "generated_password": generated_password,
        "email_sent": email_sent,
        "email_status": email_status,
    })


@admin_bp.route("/mentor/edit/<mentor_id>", methods=["POST"])
@admin_required
def edit_mentor(mentor_id):
    """Edit an existing mentor (AJAX)."""
    data = request.get_json()
    email = data.get("email", "").strip().lower()
    
    if dm.email_exists("mentors", email, exclude_id=mentor_id):
        return jsonify({"success": False, "message": "Email already exists."})
        
    name = data.get("name", "").strip()
    updates = {
        "name": name,
        "email": email,
        "avatar": "".join([part[0].upper() for part in name.split() if part][:2]),
        "phone": data.get("phone", ""),
        "specialty": data.get("specialty", ""),
        "experience_years": int(data.get("experience_years", 5)),
        "bio": data.get("bio", ""),
        "courses_assigned": data.get("courses_assigned", []),
        "qualification": data.get("qualification", ""),
        "linkedin": data.get("linkedin", ""),
        "location": data.get("location", ""),
        "skills": [s.strip() for s in data.get("skills", "").split(",") if s.strip()]
    }
    if data.get("password"):
        updates["password"] = data.get("password")
        
    result = dm.update("mentors", mentor_id, updates)
    
    # Update courses with mentor name
    for cid in updates["courses_assigned"]:
        dm.update("courses", cid, {"mentor_id": mentor_id, "mentor_name": name})
        
    return jsonify({"success": True, "mentor": result})


@admin_bp.route("/mentor/delete/<mentor_id>", methods=["POST"])
@admin_required
def delete_mentor(mentor_id):
    """Delete a mentor (AJAX)."""
    result = dm.delete("mentors", mentor_id)
    return jsonify({"success": result})


@admin_bp.route("/mentor/<mentor_id>/resend-credentials", methods=["POST"])
@admin_required
def resend_mentor_credentials(mentor_id):
    """Generate a fresh password for a mentor and email it to them."""
    mentor = dm.get_by_id("mentors", mentor_id)
    if not mentor:
        return jsonify({"success": False, "message": "Mentor not found."})

    import secrets
    new_password = secrets.token_urlsafe(6)
    dm.update("mentors", mentor_id, {"password": new_password, "must_change_password": True})

    email_sent, email_status = send_credentials_email(
        to_email=mentor["email"], name=mentor["name"], role="mentor",
        login_url=url_for("auth.login_mentor", _external=True),
        password=new_password,
    )
    return jsonify({
        "success": True,
        "generated_password": new_password,
        "email_sent": email_sent,
        "email_status": email_status,
    })


# ------------------------------------------------------------------
# Course CRUD operations
# ------------------------------------------------------------------

@admin_bp.route("/course/create", methods=["POST"])
@admin_required
def create_course():
    """Create a new course (AJAX)."""
    data = request.get_json()
    title = data.get("title", "").strip()
    
    # Check if mentor exists
    mentor_id = data.get("mentor_id")
    mentor = dm.get_by_id("mentors", mentor_id)
    mentor_name = mentor.get("name", "Unknown Mentor") if mentor else "Unknown Mentor"
    
    course = {
        "title": title,
        "slug": "-".join(title.lower().split()),
        "description": data.get("description", ""),
        "category": data.get("category", "General"),
        "level": data.get("level", "Beginner"),
        "duration_weeks": int(data.get("duration_weeks", 8)),
        "lessons_total": int(data.get("lessons_total", 32)),
        "price_original": int(data.get("price_original", 13000)),
        "price_current": int(data.get("price_current", 6550)),
        "rating": 4.5,
        "enrolled_count": 0,
        "mentor_id": mentor_id,
        "mentor_name": mentor_name,
        "thumbnail_color": data.get("thumbnail_color", "#4facfe"),
        "icon": data.get("icon", "📚"),
        "topics": [t.strip() for t in data.get("topics", "").split(",") if t.strip()],
        "certificate": True,
        "status": data.get("status", "active")
    }
    result = dm.create("courses", course)
    
    # Update mentor's courses_assigned list
    if mentor:
        assigned = mentor.get("courses_assigned", [])
        if result["id"] not in assigned:
            assigned.append(result["id"])
            dm.update("mentors", mentor_id, {"courses_assigned": assigned})
            
    return jsonify({"success": True, "course": result})


@admin_bp.route("/course/edit/<course_id>", methods=["POST"])
@admin_required
def edit_course(course_id):
    """Edit an existing course (AJAX)."""
    data = request.get_json()
    title = data.get("title", "").strip()
    mentor_id = data.get("mentor_id")
    mentor = dm.get_by_id("mentors", mentor_id)
    mentor_name = mentor.get("name", "Unknown Mentor") if mentor else "Unknown Mentor"
    
    updates = {
        "title": title,
        "slug": "-".join(title.lower().split()),
        "description": data.get("description", ""),
        "category": data.get("category", "General"),
        "level": data.get("level", "Beginner"),
        "duration_weeks": int(data.get("duration_weeks", 8)),
        "lessons_total": int(data.get("lessons_total", 32)),
        "price_original": int(data.get("price_original", 13000)),
        "price_current": int(data.get("price_current", 6550)),
        "mentor_id": mentor_id,
        "mentor_name": mentor_name,
        "thumbnail_color": data.get("thumbnail_color", "#4facfe"),
        "icon": data.get("icon", "📚"),
        "topics": [t.strip() for t in data.get("topics", "").split(",") if t.strip()],
        "status": data.get("status", "active")
    }
    result = dm.update("courses", course_id, updates)
    
    # Sync with mentor lists
    if mentor:
        assigned = mentor.get("courses_assigned", [])
        if course_id not in assigned:
            assigned.append(course_id)
            dm.update("mentors", mentor_id, {"courses_assigned": assigned})
            
    return jsonify({"success": True, "course": result})


@admin_bp.route("/course/delete/<course_id>", methods=["POST"])
@admin_required
def delete_course(course_id):
    """Delete a course (AJAX)."""
    result = dm.delete("courses", course_id)
    return jsonify({"success": result})


@admin_bp.route("/settings/save", methods=["POST"])
@main_admin_required
def save_settings():
    """Save system settings (AJAX). Main-Admin-only — affects the whole platform."""
    data = request.get_json()
    updates = {
        "app_name": data.get("app_name", "Prime Vector"),
        "tagline": data.get("tagline", "Your vector towards success"),
        "email": data.get("email", ""),
        "phone": data.get("phone", ""),
        "address": data.get("address", ""),
        "maintenance_mode": data.get("maintenance_mode", "no"),
        "allow_registrations": data.get("allow_registrations", "yes"),
        "logo_url": "/static/images/primevector_logo.png"
    }
    dm._write("settings", updates)
    return jsonify({"success": True, "settings": updates})
