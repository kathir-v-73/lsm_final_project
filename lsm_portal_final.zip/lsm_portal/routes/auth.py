"""
Prime Vector LSM Portal – Authentication Routes
Handles login, logout, and session management for all three roles.
"""

from flask import (
    Blueprint, render_template, request,
    redirect, url_for, session, jsonify, flash
)
from functools import wraps
from utils.data_manager import DataManager
from pathlib import Path
import os

# ------------------------------------------------------------------
# Blueprint Setup
# ------------------------------------------------------------------
auth_bp = Blueprint("auth", __name__)

# Initialise data manager (DATA_DIR resolved relative to this file)
_BASE = Path(__file__).resolve().parent.parent
dm = DataManager(_BASE / "data")


# ------------------------------------------------------------------
# Login Required Decorators
# ------------------------------------------------------------------

def student_required(f):
    """Decorator – ensures user is logged in as a student."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get("role") != "student":
            flash("Please log in as a student to access this page.", "warning")
            return redirect(url_for("auth.login_student"))
        return f(*args, **kwargs)
    return decorated


def mentor_required(f):
    """Decorator – ensures user is logged in as a mentor."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get("role") != "mentor":
            flash("Please log in as a mentor to access this page.", "warning")
            return redirect(url_for("auth.login_mentor"))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    """Decorator – ensures user is logged in as an admin."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Please log in as an admin to access this page.", "warning")
            return redirect(url_for("auth.login_admin"))
        return f(*args, **kwargs)
    return decorated


def main_admin_required(f):
    """
    Decorator – ensures the logged-in admin is specifically the Main Admin.
    Use for destructive/critical actions: deleting or demoting other admins,
    changing platform-wide settings, transferring main-admin ownership.
    Must be stacked UNDER @admin_required (admin_required runs first).
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Please log in as an admin to access this page.", "warning")
            return redirect(url_for("auth.login_admin"))
        admin = dm.get_by_id("admins", session.get("user_id"))
        if not admin or admin.get("admin_level") != "main":
            if request.is_json or request.path.startswith("/admin/"):
                return jsonify({"success": False, "message": "Only the Main Admin can perform this action."}), 403
            flash("Only the Main Admin can perform this action.", "warning")
            return redirect(url_for("admin.dashboard"))
        return f(*args, **kwargs)
    return decorated


@auth_bp.route("/portal-access")
def portal_access():
    """
    Role-selection page (Student / Mentor / Admin login cards).
    Intentionally NOT on the public landing page — visitors only see
    course content + Enroll Now there; this link is for people who
    already have credentials issued by the admin.
    """
    return render_template("auth/portal_access.html")


# ------------------------------------------------------------------
# Student Login
# ------------------------------------------------------------------

@auth_bp.route("/login/student", methods=["GET", "POST"])
def login_student():
    """Render and process the student login form."""
    if session.get("role") == "student":
        return redirect(url_for("student.dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        remember = request.form.get("remember", False)

        # Validate credentials against students.json
        student = dm.find_one("students", {"email": email})
        if student and student.get("password") == password:
            session["role"] = "student"
            session["user_id"] = student["id"]
            session["user_name"] = student["name"]
            session["user_email"] = student["email"]
            session["user_avatar"] = student.get("avatar", "ST")
            if remember:
                session.permanent = True
            if student.get("must_change_password"):
                return jsonify({"success": True, "redirect": url_for("auth.change_password")})
            return jsonify({"success": True, "redirect": url_for("student.dashboard")})
        else:
            return jsonify({"success": False, "message": "Invalid email or password. Please try again."})

    return render_template("auth/login_student.html")


# ------------------------------------------------------------------
# Mentor Login
# ------------------------------------------------------------------

@auth_bp.route("/login/mentor", methods=["GET", "POST"])
def login_mentor():
    """Render and process the mentor login form."""
    if session.get("role") == "mentor":
        return redirect(url_for("mentor.dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        remember = request.form.get("remember", False)

        mentor = dm.find_one("mentors", {"email": email})
        if mentor and mentor.get("password") == password:
            session["role"] = "mentor"
            session["user_id"] = mentor["id"]
            session["user_name"] = mentor["name"]
            session["user_email"] = mentor["email"]
            session["user_avatar"] = mentor.get("avatar", "MT")
            if remember:
                session.permanent = True
            if mentor.get("must_change_password"):
                return jsonify({"success": True, "redirect": url_for("auth.change_password")})
            return jsonify({"success": True, "redirect": url_for("mentor.dashboard")})
        else:
            return jsonify({"success": False, "message": "Invalid email or password. Please try again."})

    return render_template("auth/login_mentor.html")


# ------------------------------------------------------------------
# Admin Login
# ------------------------------------------------------------------

@auth_bp.route("/login/admin", methods=["GET", "POST"])
def login_admin():
    """Render and process the admin login form."""
    if session.get("role") == "admin":
        return redirect(url_for("admin.dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        remember = request.form.get("remember", False)

        admin = dm.find_one("admins", {"email": email})
        if admin and admin.get("password") == password:
            session["role"] = "admin"
            session["user_id"] = admin["id"]
            session["user_name"] = admin["name"]
            session["user_email"] = admin["email"]
            session["user_avatar"] = admin.get("avatar", "AD")
            if remember:
                session.permanent = True
            return jsonify({"success": True, "redirect": url_for("admin.dashboard")})
        else:
            return jsonify({"success": False, "message": "Invalid email or password. Please try again."})

    return render_template("auth/login_admin.html")


# ------------------------------------------------------------------
# Forced Password Change (first login after admin-generated credentials)
# ------------------------------------------------------------------

@auth_bp.route("/change-password", methods=["GET", "POST"])
def change_password():
    """
    Shown right after a student/mentor's first login when their account
    was created with an admin-generated password (must_change_password
    flag). Clears the flag once a new password is set.
    """
    role = session.get("role")
    user_id = session.get("user_id")
    if not role or not user_id or role not in ("student", "mentor"):
        return redirect(url_for("auth.portal_access"))

    collection = "students" if role == "student" else "mentors"

    if request.method == "POST":
        new_password = request.form.get("new_password", "")
        confirm_password = request.form.get("confirm_password", "")

        if len(new_password) < 6:
            return jsonify({"success": False, "message": "Password must be at least 6 characters."})
        if new_password != confirm_password:
            return jsonify({"success": False, "message": "Passwords do not match."})

        dm.update(collection, user_id, {"password": new_password, "must_change_password": False})
        dest = "student.dashboard" if role == "student" else "mentor.dashboard"
        return jsonify({"success": True, "redirect": url_for(dest)})

    return render_template("auth/change_password.html", role=role)


# ------------------------------------------------------------------
# Logout
# ------------------------------------------------------------------

@auth_bp.route("/logout")
def logout():
    """Clear session and redirect to landing page."""
    role = session.get("role", "student")
    session.clear()
    flash("You have been logged out successfully.", "info")
    return redirect(url_for("main.landing"))
