"""
Prime Vector LSM Portal – Student Routes
All protected routes for the student dashboard.
"""

from flask import Blueprint, render_template, session, jsonify, request
from pathlib import Path
from datetime import datetime
from werkzeug.utils import secure_filename
from utils.data_manager import DataManager
from routes.auth import student_required

student_bp = Blueprint("student", __name__, url_prefix="/student")

_BASE = Path(__file__).resolve().parent.parent
dm = DataManager(_BASE / "data")
_UPLOADS_ROOT = _BASE / "static" / "uploads" / "assignments"


@student_bp.route("/dashboard")
@student_required
def dashboard():
    """Main student dashboard – loads all data for the logged-in student."""
    user_id = session.get("user_id")

    # Fetch student profile
    student = dm.get_by_id("students", user_id)
    if not student:
        return "Student not found", 404

    # Fetch all courses and filter enrolled ones
    all_courses = dm.get_all("courses")
    enrolled_ids = student.get("courses_enrolled", [])
    enrolled_courses = [c for c in all_courses if c["id"] in enrolled_ids]

    # Fetch assignments for this student
    all_assignments = dm.get_all("assignments")
    my_assignments = [a for a in all_assignments if user_id in a.get("assigned_to", [])]

    # Fetch notifications for this student
    all_notifications = dm.get_all("notifications")
    my_notifications = [n for n in all_notifications if n.get("user_id") == user_id]
    unread_count = sum(1 for n in my_notifications if not n.get("read", True))

    # Fetch announcements (target student or all)
    announcements = [
        a for a in dm.get_all("announcements")
        if "student" in a.get("target_roles", [])
    ]

    # Dashboard statistics JSON for charts
    dashboard_data = dm.find_one("dashboard", {}) or {}

    # Progress data per course (simulated from student's overall_progress)
    course_progress = {}
    for course in enrolled_courses:
        # Simulate per-course progress spread around overall
        import random
        random.seed(hash(user_id + course["id"]))
        variance = random.randint(-15, 15)
        prog = min(100, max(0, student.get("overall_progress", 50) + variance))
        course_progress[course["id"]] = prog

    # Video watch progress for enrolled courses
    all_video_progress = dm.get_all("video_progress")
    my_video_progress = {vp["lesson_id"]: vp for vp in all_video_progress if vp.get("student_id") == user_id}

    # Zoom Q&A / meeting sessions targeted at this student
    all_sessions = dm.get_all("sessions")
    my_sessions = [s for s in all_sessions if user_id in s.get("target_students", [])]
    my_sessions.sort(key=lambda s: s.get("scheduled_at", ""))

    return render_template(
        "student/dashboard.html",
        student=student,
        enrolled_courses=enrolled_courses,
        course_progress=course_progress,
        assignments=my_assignments,
        notifications=my_notifications,
        unread_count=unread_count,
        announcements=announcements[:3],
        dashboard_data=dashboard_data,
        my_video_progress=my_video_progress,
        my_sessions=my_sessions,
    )


@student_bp.route("/notifications/mark-read", methods=["POST"])
@student_required
def mark_notifications_read():
    """Mark all notifications as read for this student (AJAX)."""
    user_id = session.get("user_id")
    all_notifications = dm.get_all("notifications")
    for n in all_notifications:
        if n.get("user_id") == user_id:
            n["read"] = True
    dm._write("notifications", all_notifications)
    return jsonify({"success": True})


@student_bp.route("/profile/update", methods=["POST"])
@student_required
def update_profile():
    """Update student profile fields (AJAX)."""
    user_id = session.get("user_id")
    data = request.get_json()
    allowed_fields = ["phone", "bio", "linkedin", "location"]
    updates = {k: v for k, v in data.items() if k in allowed_fields}
    result = dm.update("students", user_id, updates)
    if result:
        return jsonify({"success": True, "message": "Profile updated successfully!"})
    return jsonify({"success": False, "message": "Update failed."})


@student_bp.route("/session/<session_id>/join", methods=["POST"])
@student_required
def join_session(session_id):
    """
    Log that this student joined a Zoom Q&A/meeting session, then hand
    back the Zoom URL for the client to open in a new tab. This is how
    attendance is captured without needing Zoom's server-to-server API.
    """
    user_id = session.get("user_id")
    sess = dm.get_by_id("sessions", session_id)
    if not sess:
        return jsonify({"success": False, "message": "Session not found."})
    if user_id not in sess.get("target_students", []):
        return jsonify({"success": False, "message": "This session isn't for you."})

    attendance = sess.get("attendance", [])
    record = next((a for a in attendance if a.get("student_id") == user_id), None)
    now_iso = datetime.now().isoformat()
    if record:
        record["joined_at"] = now_iso
        record["attended"] = True
    else:
        attendance.append({"student_id": user_id, "joined_at": now_iso, "left_at": None, "attended": True})

    dm.update("sessions", session_id, {"attendance": attendance})
    return jsonify({"success": True, "zoom_join_url": sess["zoom_join_url"]})


@student_bp.route("/session/<session_id>/leave", methods=["POST"])
@student_required
def leave_session(session_id):
    """Log that this student left/finished a session (called from a 'Mark as finished' button)."""
    user_id = session.get("user_id")
    sess = dm.get_by_id("sessions", session_id)
    if not sess:
        return jsonify({"success": False, "message": "Session not found."})

    attendance = sess.get("attendance", [])
    record = next((a for a in attendance if a.get("student_id") == user_id), None)
    if record:
        record["left_at"] = datetime.now().isoformat()
        dm.update("sessions", session_id, {"attendance": attendance})

    return jsonify({"success": True})


@student_bp.route("/video/progress", methods=["POST"])
@student_required
def update_video_progress():
    """
    Upsert watch-time progress for a lesson. Called periodically (~every
    10s) by the player, plus once on pause/ended/tab-close. Marks a lesson
    'completed' once 90% has been watched (standard LMS threshold — video
    players don't always report exactly 100%).
    """
    user_id = session.get("user_id")
    data = request.get_json(silent=True) or {}
    lesson_id = data.get("lesson_id")
    course_id = data.get("course_id")
    seconds_watched = data.get("seconds_watched")

    if not lesson_id or not course_id or seconds_watched is None:
        return jsonify({"success": False, "message": "lesson_id, course_id and seconds_watched are required."}), 400

    course = dm.get_by_id("courses", course_id)
    lesson = next((l for l in (course.get("lessons", []) if course else []) if l["id"] == lesson_id), None)
    duration = lesson["duration_seconds"] if lesson else None

    existing = dm.find_one("video_progress", {"student_id": user_id, "lesson_id": lesson_id})
    seconds_watched = max(float(seconds_watched), existing.get("seconds_watched", 0) if existing else 0)
    percent_watched = round((seconds_watched / duration) * 100, 1) if duration else 0
    completed = duration is not None and seconds_watched >= 0.9 * duration

    payload = {
        "student_id": user_id,
        "lesson_id": lesson_id,
        "course_id": course_id,
        "seconds_watched": seconds_watched,
        "duration_seconds": duration,
        "percent_watched": min(percent_watched, 100),
        "completed": completed,
        "last_watched_at": datetime.now().isoformat(),
    }

    if existing:
        dm.update("video_progress", existing["id"], payload)
    else:
        dm.create("video_progress", payload)

    return jsonify({"success": True, "completed": completed, "percent_watched": payload["percent_watched"]})


@student_bp.route("/assignment/<assignment_id>/submit", methods=["POST"])
@student_required
def submit_assignment(assignment_id):
    """
    Submit (or re-submit after a revision request) files for an assignment.
    Accepts multipart/form-data with one or more files under 'files'.
    """
    user_id = session.get("user_id")
    assignment = dm.get_by_id("assignments", assignment_id)
    if not assignment:
        return jsonify({"success": False, "message": "Assignment not found."})
    if user_id not in assignment.get("assigned_to", []):
        return jsonify({"success": False, "message": "This assignment isn't assigned to you."})

    uploaded_files = request.files.getlist("files")
    if not uploaded_files or all(f.filename == "" for f in uploaded_files):
        return jsonify({"success": False, "message": "Please attach at least one file."})

    dest_dir = _UPLOADS_ROOT / assignment_id / user_id
    dest_dir.mkdir(parents=True, exist_ok=True)

    saved_files = []
    for f in uploaded_files:
        if not f.filename:
            continue
        filename = secure_filename(f.filename)
        f.save(dest_dir / filename)
        saved_files.append({
            "filename": filename,
            "url": f"/static/uploads/assignments/{assignment_id}/{user_id}/{filename}",
        })

    submissions = assignment.get("submissions", [])
    existing = next((s for s in submissions if s.get("student_id") == user_id), None)

    now_iso = datetime.now().isoformat()
    if existing:
        existing["files"] = saved_files
        existing["submitted_at"] = now_iso
        existing["status"] = "submitted"
        existing["revision_count"] = existing.get("revision_count", 0) + (1 if existing.get("status") == "needs_revision" else 0)
    else:
        submissions.append({
            "student_id": user_id,
            "submitted_at": now_iso,
            "files": saved_files,
            "status": "submitted",
            "mentor_feedback": "",
            "mentor_feedback_at": None,
            "revision_notes": "",
            "revision_count": 0,
        })

    dm.update("assignments", assignment_id, {"submissions": submissions})

    # Notify the mentor
    student = dm.get_by_id("students", user_id)
    dm.create("notifications", {
        "user_id": assignment.get("mentor_id"),
        "user_role": "mentor",
        "title": "New Assignment Submission",
        "message": f"{student['name']} submitted \"{assignment['title']}\" for review.",
        "type": "submission",
        "read": False,
        "timestamp": now_iso,
        "icon": "📥",
    })

    return jsonify({"success": True, "message": "Assignment submitted! Your mentor will review it soon."})
