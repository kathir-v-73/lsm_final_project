"""
Prime Vector LSM Portal – Mentor Routes
All protected routes for the mentor dashboard.
"""

from flask import Blueprint, render_template, session, jsonify, request
from pathlib import Path
from datetime import datetime
from utils.data_manager import DataManager
from routes.auth import mentor_required

mentor_bp = Blueprint("mentor", __name__, url_prefix="/mentor")

_BASE = Path(__file__).resolve().parent.parent
dm = DataManager(_BASE / "data")


@mentor_bp.route("/dashboard")
@mentor_required
def dashboard():
    """Main mentor dashboard – loads all relevant mentor data."""
    user_id = session.get("user_id")

    # Mentor profile
    mentor = dm.get_by_id("mentors", user_id)
    if not mentor:
        return "Mentor not found", 404

    # Assigned students
    all_students = dm.get_all("students")
    assigned_ids = mentor.get("students_assigned", [])
    my_students = [s for s in all_students if s["id"] in assigned_ids]

    # Assigned courses
    all_courses = dm.get_all("courses")
    course_ids = mentor.get("courses_assigned", [])
    my_courses = [c for c in all_courses if c["id"] in course_ids]

    # Assignments this mentor has created
    all_assignments = dm.get_all("assignments")
    my_assignments = [a for a in all_assignments if a.get("mentor_id") == user_id]

    # Pending submissions (submitted but not graded by mentor's assigned students)
    pending_reviews = []
    all_submissions_flat = []
    for assignment in my_assignments:
        for submission in assignment.get("submissions", []):
            student_record = dm.get_by_id("students", submission.get("student_id"))
            flat = {
                **submission,
                "assignment_id": assignment["id"],
                "assignment_title": assignment["title"],
                "course_title": assignment.get("course_title", ""),
                "student_name": student_record["name"] if student_record else "Unknown Student",
            }
            all_submissions_flat.append(flat)
            if submission.get("status") != "graded":
                pending_reviews.append({
                    "assignment_title": assignment["title"],
                    "student_id": submission["student_id"],
                    "submitted_at": submission["submitted_at"],
                })

    # Video engagement: for each of my students, their watch progress on my courses' lessons
    all_video_progress = dm.get_all("video_progress")
    my_course_ids = set(course_ids)
    video_engagement = []
    for vp in all_video_progress:
        if vp.get("course_id") in my_course_ids and vp.get("student_id") in assigned_ids:
            student_record = next((s for s in my_students if s["id"] == vp["student_id"]), None)
            course_record = next((c for c in my_courses if c["id"] == vp["course_id"]), None)
            lesson_record = None
            if course_record:
                lesson_record = next((l for l in course_record.get("lessons", []) if l["id"] == vp["lesson_id"]), None)
            video_engagement.append({
                **vp,
                "student_name": student_record["name"] if student_record else "Unknown",
                "course_title": course_record["title"] if course_record else "",
                "lesson_title": lesson_record["title"] if lesson_record else vp["lesson_id"],
            })

    # Zoom Q&A sessions this mentor has scheduled
    all_sessions = dm.get_all("sessions")
    my_sessions = [s for s in all_sessions if s.get("mentor_id") == user_id and s.get("type") == "mentor_qa"]

    # Admin-scheduled meetings this mentor is invited to
    my_meetings = [s for s in all_sessions if s.get("type") == "mentor_meeting" and user_id in s.get("target_mentors", [])]
    my_meetings.sort(key=lambda s: s.get("scheduled_at", ""))

    all_notifications = dm.get_all("notifications")
    my_notifications = [n for n in all_notifications if n.get("user_id") == user_id]
    unread_count = sum(1 for n in my_notifications if not n.get("read", True))

    # Announcements
    announcements = [
        a for a in dm.get_all("announcements")
        if "mentor" in a.get("target_roles", [])
    ]

    # Dashboard/chart data
    dashboard_data = dm.find_one("dashboard", {}) or {}

    # Build student progress summary for charts
    student_names = [s["name"].split()[0] for s in my_students]
    student_progress = [s.get("overall_progress", 0) for s in my_students]

    return render_template(
        "mentor/dashboard.html",
        mentor=mentor,
        my_students=my_students,
        my_courses=my_courses,
        my_assignments=my_assignments,
        pending_reviews=pending_reviews,
        all_submissions=all_submissions_flat,
        video_engagement=video_engagement,
        my_sessions=my_sessions,
        my_meetings=my_meetings,
        notifications=my_notifications,
        unread_count=unread_count,
        announcements=announcements[:3],
        dashboard_data=dashboard_data,
        student_names=student_names,
        student_progress=student_progress,
    )


@mentor_bp.route("/assignment/create", methods=["POST"])
@mentor_required
def create_assignment():
    """Create a new assignment (AJAX)."""
    user_id = session.get("user_id")
    data = request.get_json()
    assignment = {
        "title": data.get("title"),
        "description": data.get("description"),
        "course_id": data.get("course_id"),
        "due_date": data.get("due_date"),
        "max_score": int(data.get("max_score", 100)),
        "difficulty": data.get("difficulty", "Medium"),
        "type": data.get("type", "Assignment"),
        "mentor_id": user_id,
        "assigned_to": data.get("assigned_to", []),
        "status": "active",
        "submissions": [],
    }
    result = dm.create("assignments", assignment)
    return jsonify({"success": True, "assignment": result})


def _find_submission(assignment, student_id):
    return next((s for s in assignment.get("submissions", []) if s.get("student_id") == student_id), None)


@mentor_bp.route("/meeting/<session_id>/join", methods=["POST"])
@mentor_required
def join_meeting(session_id):
    """Log that this mentor joined an admin-scheduled meeting; hand back the Zoom URL."""
    user_id = session.get("user_id")
    sess = dm.get_by_id("sessions", session_id)
    if not sess:
        return jsonify({"success": False, "message": "Meeting not found."})
    if user_id not in sess.get("target_mentors", []):
        return jsonify({"success": False, "message": "This meeting isn't for you."})

    attendance = sess.get("attendance", [])
    record = next((a for a in attendance if a.get("mentor_id") == user_id), None)
    now_iso = datetime.now().isoformat()
    if record:
        record["joined_at"] = now_iso
        record["attended"] = True
    else:
        attendance.append({"mentor_id": user_id, "joined_at": now_iso, "left_at": None, "attended": True})

    dm.update("sessions", session_id, {"attendance": attendance})
    return jsonify({"success": True, "zoom_join_url": sess["zoom_join_url"]})


@mentor_bp.route("/meeting/<session_id>/leave", methods=["POST"])
@mentor_required
def leave_meeting(session_id):
    """Log that this mentor left/finished an admin-scheduled meeting."""
    user_id = session.get("user_id")
    sess = dm.get_by_id("sessions", session_id)
    if not sess:
        return jsonify({"success": False, "message": "Meeting not found."})

    attendance = sess.get("attendance", [])
    record = next((a for a in attendance if a.get("mentor_id") == user_id), None)
    if record:
        record["left_at"] = datetime.now().isoformat()
        dm.update("sessions", session_id, {"attendance": attendance})

    return jsonify({"success": True})


@mentor_bp.route("/session/create", methods=["POST"])
@mentor_required
def create_session():
    """
    Schedule a Zoom Q&A session for this mentor's assigned students
    (optionally scoped to one course). Notifies every targeted student.
    """
    user_id = session.get("user_id")
    data = request.get_json(silent=True) or {}

    title = (data.get("title") or "").strip()
    zoom_join_url = (data.get("zoom_join_url") or "").strip()
    scheduled_at = data.get("scheduled_at")
    if not title or not zoom_join_url or not scheduled_at:
        return jsonify({"success": False, "message": "Title, Zoom link and scheduled time are required."})

    mentor = dm.get_by_id("mentors", user_id)
    target_students = data.get("target_students") or mentor.get("students_assigned", [])

    new_session = {
        "type": "mentor_qa",
        "mentor_id": user_id,
        "course_id": data.get("course_id", ""),
        "title": title,
        "zoom_join_url": zoom_join_url,
        "scheduled_at": scheduled_at,
        "duration_minutes": int(data.get("duration_minutes", 45)),
        "target_students": target_students,
        "attendance": [],
    }
    result = dm.create("sessions", new_session)

    now_iso = datetime.now().isoformat()
    for sid in target_students:
        dm.create("notifications", {
            "user_id": sid,
            "user_role": "student",
            "title": "Q&A Session Scheduled",
            "message": f"{mentor['name']} scheduled \"{title}\" — check your notifications to join.",
            "type": "session",
            "read": False,
            "timestamp": now_iso,
            "icon": "🎥",
        })

    return jsonify({"success": True, "session": result})


@mentor_bp.route("/submission/<assignment_id>/<student_id>/approve", methods=["POST"])
@mentor_required
def approve_submission(assignment_id, student_id):
    """
    Approve ("appreciate") a student's assignment submission.
    Only the mentor who owns the assignment may approve it.
    """
    user_id = session.get("user_id")
    assignment = dm.get_by_id("assignments", assignment_id)
    if not assignment or assignment.get("mentor_id") != user_id:
        return jsonify({"success": False, "message": "Assignment not found or not yours."})

    submission = _find_submission(assignment, student_id)
    if not submission:
        return jsonify({"success": False, "message": "Submission not found."})

    data = request.get_json(silent=True) or {}
    submission["status"] = "graded"  # "graded" doubles as the terminal/approved state
    submission["mentor_feedback"] = data.get("feedback", "Great work — approved!")
    submission["mentor_feedback_at"] = datetime.now().isoformat()
    if data.get("score") is not None:
        submission["score"] = int(data["score"])

    dm.update("assignments", assignment_id, {"submissions": assignment["submissions"]})

    # Bump the student's certificate/assignment counters
    student = dm.get_by_id("students", student_id)
    if student:
        dm.update("students", student_id, {
            "assignments_submitted": student.get("assignments_submitted", 0) + 1,
        })
        dm.create("notifications", {
            "user_id": student_id,
            "user_role": "student",
            "title": "Assignment Approved! 🎉",
            "message": f"Your mentor approved \"{assignment['title']}\". {submission['mentor_feedback']}",
            "type": "assignment_approved",
            "read": False,
            "timestamp": datetime.now().isoformat(),
            "icon": "🎉",
        })

    return jsonify({"success": True, "message": "Submission approved."})


@mentor_bp.route("/submission/<assignment_id>/<student_id>/request-revision", methods=["POST"])
@mentor_required
def request_revision(assignment_id, student_id):
    """Ask a student to revise and resubmit, with notes on what to improve."""
    user_id = session.get("user_id")
    assignment = dm.get_by_id("assignments", assignment_id)
    if not assignment or assignment.get("mentor_id") != user_id:
        return jsonify({"success": False, "message": "Assignment not found or not yours."})

    submission = _find_submission(assignment, student_id)
    if not submission:
        return jsonify({"success": False, "message": "Submission not found."})

    data = request.get_json(silent=True) or {}
    notes = (data.get("notes") or "").strip()
    if not notes:
        return jsonify({"success": False, "message": "Please describe what needs to be improved."})

    submission["status"] = "needs_revision"
    submission["revision_notes"] = notes
    submission["mentor_feedback_at"] = datetime.now().isoformat()

    dm.update("assignments", assignment_id, {"submissions": assignment["submissions"]})

    student = dm.get_by_id("students", student_id)
    dm.create("notifications", {
        "user_id": student_id,
        "user_role": "student",
        "title": "Revision Requested",
        "message": f"Your mentor asked for changes on \"{assignment['title']}\": {notes[:100]}",
        "type": "revision_requested",
        "read": False,
        "timestamp": datetime.now().isoformat(),
        "icon": "🔁",
    })

    return jsonify({"success": True, "message": "Revision request sent to the student."})
