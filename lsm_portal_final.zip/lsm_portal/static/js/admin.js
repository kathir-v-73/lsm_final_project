/**
 * Prime Vector LSM Portal – Admin Dashboard JavaScript
 * admin.js
 * 
 * Renders all Chart.js charts for the admin dashboard.
 * Data comes from ADMIN_DATA injected by the Jinja template.
 */

document.addEventListener('DOMContentLoaded', function () {

  /* -----------------------------------------------------------------------
     Monthly Enrollments Line Chart
     ----------------------------------------------------------------------- */
  const enrollCtx = document.getElementById('enrollmentChart');
  if (enrollCtx && typeof ADMIN_DATA !== 'undefined') {
    new Chart(enrollCtx, {
      type: 'line',
      data: {
        labels: ADMIN_DATA.monthlyLabels,
        datasets: [{
          label: 'Enrollments',
          data: ADMIN_DATA.monthlyData,
          fill: true,
          backgroundColor: 'rgba(14, 165, 233, 0.1)',
          borderColor: 'rgba(14, 165, 233, 0.9)',
          borderWidth: 2.5,
          tension: 0.4,
          pointBackgroundColor: '#0ea5e9',
          pointRadius: 5,
          pointHoverRadius: 8,
        }],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: 'rgba(15,23,42,0.9)',
            titleColor: '#fff',
            bodyColor: 'rgba(255,255,255,0.8)',
            cornerRadius: 8, padding: 10,
          },
        },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#9ca3af', font: { size: 11 } } },
          y: {
            grid: { color: 'rgba(14,165,233,0.06)' },
            ticks: { color: '#9ca3af', font: { size: 11 } },
          },
        },
      },
    });
  }

  /* -----------------------------------------------------------------------
     Course Popularity Doughnut
     ----------------------------------------------------------------------- */
  const courseCtx = document.getElementById('coursePopularityChart');
  if (courseCtx && typeof ADMIN_DATA !== 'undefined') {
    const colors = [
      '#6366f1', '#8b5cf6', '#f093fb', '#ff6b6b',
      '#43e97b', '#fa709a', '#4facfe', '#00f2fe',
    ];
    new Chart(courseCtx, {
      type: 'doughnut',
      data: {
        labels: ADMIN_DATA.courseLabels,
        datasets: [{
          data: ADMIN_DATA.courseData,
          backgroundColor: colors,
          borderWidth: 0,
          hoverOffset: 8,
        }],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        cutout: '65%',
        plugins: {
          legend: { position: 'bottom', labels: { font: { size: 10 }, padding: 10, usePointStyle: true } },
          tooltip: { callbacks: { label: ctx => `${ctx.label}: ${ctx.parsed}` } },
        },
      },
    });
  }

  /* -----------------------------------------------------------------------
     Weekly Activity Bar Chart (Reports section)
     ----------------------------------------------------------------------- */
  const weeklyCtx = document.getElementById('weeklyActivityChart');
  if (weeklyCtx && typeof ADMIN_DATA !== 'undefined') {
    new Chart(weeklyCtx, {
      type: 'bar',
      data: {
        labels: ADMIN_DATA.weeklyLabels,
        datasets: [
          {
            label: 'Active Students',
            data: ADMIN_DATA.weeklyStudents,
            backgroundColor: 'rgba(99, 102, 241, 0.8)',
            borderRadius: 6,
            borderSkipped: false,
          },
          {
            label: 'Assignments Submitted',
            data: ADMIN_DATA.weeklyAssignments,
            backgroundColor: 'rgba(34, 197, 94, 0.8)',
            borderRadius: 6,
            borderSkipped: false,
          },
        ],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'top', labels: { usePointStyle: true, font: { size: 11 } } } },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#9ca3af', font: { size: 11 } } },
          y: { grid: { color: 'rgba(0,0,0,0.04)' }, ticks: { color: '#9ca3af', font: { size: 11 } } },
        },
      },
    });
  }

  /* -----------------------------------------------------------------------
     Student Progress Distribution Pie (Reports section)
     ----------------------------------------------------------------------- */
  const progDistCtx = document.getElementById('progressDistChart');
  if (progDistCtx && typeof ADMIN_DATA !== 'undefined') {
    new Chart(progDistCtx, {
      type: 'pie',
      data: {
        labels: ADMIN_DATA.progressLabels,
        datasets: [{
          data: ADMIN_DATA.progressData,
          backgroundColor: [
            'rgba(239,68,68,0.85)',
            'rgba(245,158,11,0.85)',
            'rgba(99,102,241,0.85)',
            'rgba(34,197,94,0.85)',
          ],
          borderWidth: 0,
          hoverOffset: 6,
        }],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom', labels: { usePointStyle: true, font: { size: 11 }, padding: 14 } },
          tooltip: { callbacks: { label: ctx => `${ctx.label}: ${ctx.parsed}%` } },
        },
      },
    });
  }
});
