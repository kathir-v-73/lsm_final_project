/**
 * Prime Vector LSM Portal – Landing Page JavaScript
 * landing.js
 */

document.addEventListener('DOMContentLoaded', function () {
  // Smooth reveal animations for sections as user scrolls
  const revealElements = document.querySelectorAll('.login-card, .course-card-landing, .stats-banner-item');

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  revealElements.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    revealObserver.observe(el);
  });
});

// ---------------------------------------------------------------------
// Enroll Now modal — course card -> admin enrollment queue
// ---------------------------------------------------------------------
function openEnrollModal(courseId, courseTitle) {
  document.getElementById('enroll-course-id').value = courseId;
  document.getElementById('enroll-course-name').textContent = courseTitle;
  document.getElementById('enroll-modal-overlay').classList.add('active');
}

function closeEnrollModal() {
  document.getElementById('enroll-modal-overlay').classList.remove('active');
  document.getElementById('enroll-form').reset();
}

function submitEnrollment(event) {
  event.preventDefault();
  const payload = {
    course_id: document.getElementById('enroll-course-id').value,
    name: document.getElementById('enroll-name').value.trim(),
    email: document.getElementById('enroll-email').value.trim(),
    phone: document.getElementById('enroll-phone').value.trim(),
  };

  const submitBtn = event.target.querySelector('button[type="submit"]');
  submitBtn.disabled = true;
  submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Submitting...';

  fetch('/enroll', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
    .then((r) => r.json())
    .then((data) => {
      submitBtn.disabled = false;
      submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Enrollment Request';
      if (data.success) {
        closeEnrollModal();
        if (typeof showToast === 'function') {
          showToast(data.message || "Request sent! Our admin team will reach out.", 'success');
        } else {
          alert(data.message || "Request sent! Our admin team will reach out.");
        }
      } else {
        alert(data.message || 'Something went wrong. Please try again.');
      }
    })
    .catch(() => {
      submitBtn.disabled = false;
      submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Enrollment Request';
      alert('Network error — please try again.');
    });
}
