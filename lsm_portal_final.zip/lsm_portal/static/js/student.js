/**
 * Prime Vector LSM Portal – Student Dashboard JavaScript
 * student.js
 * 
 * Initialises Chart.js charts for the student dashboard.
 * All data comes from the STUDENT_DATA object injected by the template.
 */

document.addEventListener('DOMContentLoaded', function () {

  /* -----------------------------------------------------------------------
     Performance Radar / Line Chart (Overview section)
     ----------------------------------------------------------------------- */
  const perfCtx = document.getElementById('performanceChart');
  if (perfCtx && typeof STUDENT_DATA !== 'undefined') {
    new Chart(perfCtx, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Progress %',
          data: [
            Math.max(0, STUDENT_DATA.overall_progress - 35),
            Math.max(0, STUDENT_DATA.overall_progress - 22),
            Math.max(0, STUDENT_DATA.overall_progress - 15),
            Math.max(0, STUDENT_DATA.overall_progress - 8),
            Math.max(0, STUDENT_DATA.overall_progress - 3),
            STUDENT_DATA.overall_progress,
          ],
          fill: true,
          backgroundColor: 'rgba(99, 102, 241, 0.1)',
          borderColor: 'rgba(99, 102, 241, 0.8)',
          borderWidth: 2.5,
          tension: 0.4,
          pointBackgroundColor: 'rgba(99, 102, 241, 1)',
          pointRadius: 4,
          pointHoverRadius: 6,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: 'rgba(15, 23, 42, 0.9)',
            titleColor: '#fff',
            bodyColor: 'rgba(255,255,255,0.8)',
            padding: 10,
            cornerRadius: 8,
          },
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { size: 11 }, color: '#9ca3af' },
          },
          y: {
            min: 0, max: 100,
            grid: { color: 'rgba(99, 102, 241, 0.06)' },
            ticks: {
              font: { size: 11 }, color: '#9ca3af',
              callback: v => `${v}%`,
            },
          },
        },
      },
    });
  }

  /* -----------------------------------------------------------------------
     Course Progress Bar Chart (Progress section)
     ----------------------------------------------------------------------- */
  const cpCtx = document.getElementById('courseProgressChart');
  if (cpCtx && typeof STUDENT_DATA !== 'undefined') {
    new Chart(cpCtx, {
      type: 'bar',
      data: {
        labels: STUDENT_DATA.courses,
        datasets: [{
          label: 'Progress %',
          data: STUDENT_DATA.progress,
          backgroundColor: STUDENT_DATA.progress.map(p =>
            p >= 75 ? 'rgba(34, 197, 94, 0.8)' :
            p >= 40 ? 'rgba(245, 158, 11, 0.8)' : 'rgba(239, 68, 68, 0.8)'
          ),
          borderRadius: 8,
          borderSkipped: false,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: { label: ctx => `${ctx.parsed.y}%` },
          },
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { size: 10 }, maxRotation: 30, color: '#9ca3af' },
          },
          y: {
            min: 0, max: 100,
            grid: { color: 'rgba(0,0,0,0.04)' },
            ticks: { callback: v => `${v}%`, color: '#9ca3af', font: { size: 11 } },
          },
        },
      },
    });
  }

  /* -----------------------------------------------------------------------
     Grade Distribution Doughnut (Progress section)
     ----------------------------------------------------------------------- */
  const gradeCtx = document.getElementById('gradeChart');
  if (gradeCtx && typeof STUDENT_DATA !== 'undefined') {
    // Simulate grade distribution based on overall progress
    const prog = STUDENT_DATA.overall_progress;
    new Chart(gradeCtx, {
      type: 'doughnut',
      data: {
        labels: ['Completed', 'In Progress', 'Not Started'],
        datasets: [{
          data: [prog, Math.min(25, 100 - prog), Math.max(0, 100 - prog - 25)],
          backgroundColor: [
            'rgba(34, 197, 94, 0.85)',
            'rgba(99, 102, 241, 0.85)',
            'rgba(229, 231, 235, 0.85)',
          ],
          borderWidth: 0,
          hoverOffset: 6,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '72%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              font: { size: 11 },
              padding: 12,
              usePointStyle: true,
            },
          },
          tooltip: {
            callbacks: { label: ctx => `${ctx.label}: ${ctx.parsed}%` },
          },
        },
      },
    });
  }
});

// ---------------------------------------------------------------------
// Assignment submission
// ---------------------------------------------------------------------
function openSubmitModal(assignmentId, assignmentTitle) {
  document.getElementById('submit-assignment-id').value = assignmentId;
  document.getElementById('submit-assignment-title').textContent = assignmentTitle;
  document.getElementById('submit-files').value = '';
  document.getElementById('submit-assignment-modal-overlay')?.classList.add('active');
}

function closeSubmitModal() {
  document.getElementById('submit-assignment-modal-overlay')?.classList.remove('active');
}

function submitAssignmentFiles(event) {
  event.preventDefault();
  const assignmentId = document.getElementById('submit-assignment-id').value;
  const filesInput = document.getElementById('submit-files');

  if (!filesInput.files.length) {
    showToast('Please attach at least one file.', 'error');
    return;
  }

  const formData = new FormData();
  for (const file of filesInput.files) {
    formData.append('files', file);
  }

  fetch(`/student/assignment/${assignmentId}/submit`, {
    method: 'POST',
    body: formData,
  })
    .then((r) => r.json())
    .then((d) => {
      if (d.success) {
        closeSubmitModal();
        showToast(d.message || 'Assignment submitted!', 'success');
        setTimeout(() => location.reload(), 1000);
      } else {
        showToast(d.message || 'Submission failed.', 'error');
      }
    })
    .catch(() => showToast('Network error — please try again.', 'error'));
}

// ---------------------------------------------------------------------
// Lessons / video watch-time tracking
// ---------------------------------------------------------------------
let _currentLessonsCourseId = null;
let _currentLessonId = null;
let _videoProgressTimer = null;

function openLessonsModal(courseId, courseTitle, lessons) {
  _currentLessonsCourseId = courseId;
  document.getElementById('lessons-modal-course-title').textContent = courseTitle;

  const listEl = document.getElementById('lessons-list');
  listEl.innerHTML = '';

  lessons.forEach((lesson, idx) => {
    const vp = (typeof VIDEO_PROGRESS !== 'undefined' && VIDEO_PROGRESS[lesson.id]) || null;
    const pct = vp ? vp.percent_watched : 0;
    const completed = vp ? vp.completed : false;

    const row = document.createElement('div');
    row.style.cssText = 'display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--border-color, #eee);cursor:pointer;';
    row.innerHTML = `
      <div style="width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;
                  background:${completed ? 'var(--success, #22c55e)' : 'var(--bg-base, #f1f5f9)'};
                  color:${completed ? '#fff' : 'var(--text-muted, #64748b)'};">
        ${completed ? '<i class="fa-solid fa-check"></i>' : (idx + 1)}
      </div>
      <div style="flex:1;">
        <div style="font-weight:600;font-size:13px;">${lesson.title}</div>
        <div style="font-size:11px;color:var(--text-muted, #64748b);">${Math.round(lesson.duration_seconds / 60)} min · ${pct}% watched</div>
      </div>
      <i class="fa-solid fa-play" style="color:var(--primary, #6366f1);"></i>
    `;
    row.addEventListener('click', () => playLesson(courseId, lesson));
    listEl.appendChild(row);
  });

  document.getElementById('lessons-modal-overlay')?.classList.add('active');
}

function closeLessonsModal() {
  document.getElementById('lessons-modal-overlay')?.classList.remove('active');
  const player = document.getElementById('lessons-video-player');
  if (player) player.pause();
  _stopVideoProgressTracking();
}

function playLesson(courseId, lesson) {
  _currentLessonId = lesson.id;
  const wrap = document.getElementById('lessons-video-wrap');
  const player = document.getElementById('lessons-video-player');
  const status = document.getElementById('lessons-video-status');

  wrap.style.display = 'block';
  player.src = lesson.video_url;

  const vp = (typeof VIDEO_PROGRESS !== 'undefined' && VIDEO_PROGRESS[lesson.id]) || null;
  status.textContent = vp ? `Resuming — ${vp.percent_watched}% watched so far` : 'Starting from the beginning';

  if (vp && vp.seconds_watched) {
    player.currentTime = Math.min(vp.seconds_watched, lesson.duration_seconds - 2);
  }

  player.play().catch(() => { /* autoplay may be blocked; user can press play */ });

  _stopVideoProgressTracking();
  _videoProgressTimer = setInterval(() => {
    _sendVideoProgress(courseId, lesson.id, player.currentTime);
  }, 10000);

  player.onpause = () => _sendVideoProgress(courseId, lesson.id, player.currentTime);
  player.onended = () => _sendVideoProgress(courseId, lesson.id, player.currentTime);

  document.addEventListener('visibilitychange', _onVisibilityChangeSendProgress);
}

function _onVisibilityChangeSendProgress() {
  if (document.hidden && _currentLessonsCourseId && _currentLessonId) {
    const player = document.getElementById('lessons-video-player');
    if (player) _sendVideoProgress(_currentLessonsCourseId, _currentLessonId, player.currentTime, true);
  }
}

function _stopVideoProgressTracking() {
  if (_videoProgressTimer) {
    clearInterval(_videoProgressTimer);
    _videoProgressTimer = null;
  }
  document.removeEventListener('visibilitychange', _onVisibilityChangeSendProgress);
}

function _sendVideoProgress(courseId, lessonId, secondsWatched, useBeacon) {
  const payload = JSON.stringify({ course_id: courseId, lesson_id: lessonId, seconds_watched: secondsWatched });

  if (useBeacon && navigator.sendBeacon) {
    const blob = new Blob([payload], { type: 'application/json' });
    navigator.sendBeacon('/student/video/progress', blob);
    return;
  }

  fetch('/student/video/progress', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: payload,
    keepalive: true,
  }).catch(() => { /* silent — will retry on next interval */ });
}

// ---------------------------------------------------------------------
// Live sessions (Zoom Q&A) — join/leave attendance tracking
// ---------------------------------------------------------------------
function joinSession(sessionId) {
  fetch(`/student/session/${sessionId}/join`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  })
    .then((r) => r.json())
    .then((d) => {
      if (d.success) {
        window.open(d.zoom_join_url, '_blank');
        showToast('Joined — attendance recorded. Click "Mark Finished" when the call ends.', 'success');
        setTimeout(() => location.reload(), 1200);
      } else {
        showToast(d.message || 'Could not join session.', 'error');
      }
    })
    .catch(() => showToast('Network error — please try again.', 'error'));
}

function leaveSession(sessionId) {
  if (!confirm('Mark this session as finished? This records your attendance as complete.')) return;
  fetch(`/student/session/${sessionId}/leave`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  })
    .then((r) => r.json())
    .then((d) => {
      if (d.success) {
        showToast('Attendance recorded. See you next time!', 'success');
        setTimeout(() => location.reload(), 1000);
      } else {
        showToast('Could not update attendance.', 'error');
      }
    })
    .catch(() => showToast('Network error — please try again.', 'error'));
}
