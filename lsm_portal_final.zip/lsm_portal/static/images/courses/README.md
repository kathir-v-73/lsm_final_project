# Course Card Images — Save With These Exact Filenames

Drop your photos into this folder (`static/images/courses/`) using the **exact
filename** shown below for each course. The landing page already looks for
these paths — nothing else needs to change once the file exists here.

| Course | Save image as |
|---|---|
| Artificial Intelligence | `artificial-intelligence.jpg` |
| Machine Learning | `machine-learning.jpg` |
| Data Science | `data-science.jpg` |
| Cybersecurity & Ethical Hacking | `cybersecurity.jpg` |
| Full Stack Web Development | `full-stack-web-development.jpg` |
| UI/UX Design | `ui-ux-design.jpg` |
| Core Java Programming | `core-java.jpg` |
| IoT & Robotics | `iot-robotics.jpg` |
| VLSI Design | `vlsi-design.jpg` |
| AutoCAD & CATIA | `autocad-catia.jpg` |
| AWS & Cloud Computing | `aws-cloud-computing.jpg` |
| Digital Marketing | `digital-marketing.jpg` |
| Human Resources Management | `hr-management.jpg` |
| Finance & Accounting | `finance-accounting.jpg` |
| Microsoft Azure Cloud | `microsoft-azure.jpg` |

## Rules
- **File type:** `.jpg` (you can also use `.png` — see below).
- **Recommended size:** 800×500px (16:10), under 300KB each so the landing page loads fast.
- **Filenames are case-sensitive** on most servers — keep them lowercase with hyphens exactly as above.
- Don't rename the course inside `courses.json` without also renaming its image — the `slug` field in
  `data/courses.json` is what generates the filename the page looks for.

## Using `.png` instead of `.jpg`
If your images are PNG, either:
1. Convert them to `.jpg` before saving here (simplest), or
2. Open `data/courses.json` and change that course's `"image"` value from `.jpg` to `.png`.

## What happens if an image is missing
The card automatically falls back to the current gradient + emoji icon, so the
site never breaks — it just quietly waits for you to drop the real photo in.

## Adding a brand-new course later
Whatever `slug` you give the new course in `data/courses.json`, save its image
as `<that-slug>.jpg` here. Example: slug `python-programming` → filename
`python-programming.jpg`.
